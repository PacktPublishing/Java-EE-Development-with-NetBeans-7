/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packtpub.netbeansjavaee.netbeansvisualcues;

/**
 *
 * @author heffel
 */
public interface Shape {

    public double area();

    public double perimeter();
}
